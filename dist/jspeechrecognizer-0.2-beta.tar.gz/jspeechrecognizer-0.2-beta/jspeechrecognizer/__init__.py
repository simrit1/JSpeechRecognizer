from jspeechrecognizer.speech import SpeechRecognizer, GoogleRecognizer, VoskRecognizer, JarvisVAD
